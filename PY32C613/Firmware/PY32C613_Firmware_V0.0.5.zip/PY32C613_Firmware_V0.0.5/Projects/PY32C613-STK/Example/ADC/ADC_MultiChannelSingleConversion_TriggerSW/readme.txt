================================================================================
                                样例使用说明
                             Sample Description
================================================================================
功能描述：
此样例演示了ADC单次轮询(Polling)的方式采样AN0,AN1,AN4通道,并将采样到的ADC值存放
在数组adc_value中。

Function descriptions:
This sample demonstrates the ADC single-channel polling mode to sample channels 
AN0, AN1, and AN4, and storing the sampled ADC values in an array adc_value.
================================================================================
测试环境：
测试用板：PY32C613_STK
MDK版本： 5.28
IAR版本： 9.20
GCC版本： GNU Arm Embedded Toolchain 10.3-2021.10

Test environment:
Test board: PY32C613_STK
MDK Version: 5.28
IAR Version: 9.20
GCC Version: GNU Arm Embedded Toolchain 10.3-2021.10
================================================================================
使用步骤：
1. 编译下载程序到MCU，并运行；
2. 通道0，1，4的ADC值分别存放在adc_value[0]、adc_value[1]、adc_value[2]，可通过
watch窗口查看它们的值。

Example execution steps:
1.Compile and download the program to the MCU and run it.
2.The ADC values of channels 0, 1, and 4 are stored in adc_value[0], adc_value[1],
adc_value[2], their values can be viewed through the watch window.
================================================================================
注意事项：

Notes:

================================================================================