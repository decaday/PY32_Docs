================================================================================
                                样例使用说明
                             Sample Description
================================================================================
功能描述：
此样例演示了通过ADC触发DMA搬运ADC_DR中的数据，配置CH0(PA00)为ADC的模拟输入通道，
ADC触发DMA，DMA会把采样数据搬运到变量gADCxConvertedData中。

Function descriptions:
This sample demonstrates the transfer of ADC data from ADC_DR using DMA 
triggered by ADC. It configures CH0(PA00) as the analog input channel for ADC. 
The ADC triggers DMA to transfer the sampled data.ADC triggers DMA, which will 
transfer the sampled data to the variable gADCxConvertedData.
================================================================================
测试环境：
测试用板：PY32C613_STK
MDK版本： 5.28
IAR版本： 9.20
GCC版本： GNU Arm Embedded Toolchain 10.3-2021.10

Test environment:
Test board: PY32C613_STK
MDK Version: 5.28
IAR Version: 9.20
GCC Version: GNU Arm Embedded Toolchain 10.3-2021.10
================================================================================
使用步骤：
1. 编译下载程序到MCU，并运行；
2. DMA把ADC的采样数据搬运到变量gADCxConvertedData中，搬运完成，可通过watch
窗口查看变量gADCxConvertedData的值。

Example execution steps:
1.Compile and download the program to the MCU and run it.
2.DMA transfers the sampling data of ADC to the variable gADCxConvertedData. 
After the transfer is completed, the value of the variable gADCxConvertedData 
can be viewed through the watch window.
================================================================================
注意事项：

Notes:

================================================================================