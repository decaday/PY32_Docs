================================================================================
                                样例使用说明
                             Sample Description
================================================================================
功能描述：
此样例演示了ADC模块的VCC采样功能，通过采样VREFINT的值，计算得出VCC的值，可通过
watch窗口查看VCC的电压值。

Function descriptions:
This sample demonstrates the VCC sampling functionality of the ADC module. By 
sampling the value of VREFINT and performing calculations, the voltage value of 
the VCC can be viewed through the watch window.
================================================================================
测试环境：
测试用板：PY32C613_STK
MDK版本： 5.28
IAR版本： 9.20
GCC版本： GNU Arm Embedded Toolchain 10.3-2021.10

Test environment:
Test board: PY32C613_STK
MDK Version: 5.28
IAR Version: 9.20
GCC Version: GNU Arm Embedded Toolchain 10.3-2021.10
================================================================================
使用步骤：
1. 编译下载程序到MCU，并运行；
2. 在debug模式下通过watch窗口中查看VCC的电压值（即变量T_VCC的值，单位为mV）。

Example execution steps:
1.Compile and download the program to the MCU and run it.
2.In debug mode, view the voltage value of VCC (i.e. the value of variable TVCC, 
in mV) through the watch window.
================================================================================
注意事项：

Notes:

================================================================================