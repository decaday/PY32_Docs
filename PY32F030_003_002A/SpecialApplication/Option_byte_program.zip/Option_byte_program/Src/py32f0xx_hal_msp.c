/**
  ******************************************************************************
  * @file    py32f0xx_hal_msp.c
  * @author  MCU Application Team
  * @Version V1.0.0
  * @Date    2020-10-19
  * @brief   This file provides code for the MSP Initialization
  *          and de-Initialization codes.
  ******************************************************************************
  */


/* Includes ------------------------------------------------------------------*/
#include "main.h"


/**
  * Initializes the Global MSP.
  */
void HAL_MspInit(void)
{

}
/**
 * ���ڹܽ�ӳ��
*/
void HAL_UART_MspInit(UART_HandleTypeDef *huart)
{
  GPIO_InitTypeDef GPIO_InitStruct;

  UART_CH340E_TX_GPIO_CLK_ENABLE();
  UART_CH340E_RX_GPIO_CLK_ENABLE();

  UART_CH340E_CLK_ENABLE();

  GPIO_InitStruct.Pin = UART_CH340E_TX_PIN;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  GPIO_InitStruct.Alternate = UART_CH340E_TX_AF;

  HAL_GPIO_Init(UART_CH340E_TX_GPIO_PORT, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = UART_CH340E_RX_PIN;
  GPIO_InitStruct.Alternate = UART_CH340E_RX_AF;
  HAL_GPIO_Init(UART_CH340E_RX_GPIO_PORT, &GPIO_InitStruct);

  HAL_NVIC_SetPriority(UART_CH340E_IRQn, 2, 1);
  HAL_NVIC_EnableIRQ(UART_CH340E_IRQn);
}





