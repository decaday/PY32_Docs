#include "main.h"

/* OB_BOR_DISABLE/OB_BOR_DISABLE */
#define USER_BOR_ENABLE_CONFIG (OB_BOR_ENABLE)
/* OB_BOR_LEVEL_1p7_1p8/
OB_BOR_LEVEL_1p9_2p0/
OB_BOR_LEVEL_2p1_2p2/
OB_BOR_LEVEL_2p3_2p4/
OB_BOR_LEVEL_2p5_2p6/
OB_BOR_LEVEL_2p7_2p8/
OB_BOR_LEVEL_2p9_3p0/
OB_BOR_LEVEL_3p1_3p2 */
#define USER_BOR_LEVEL_CONFIG (OB_BOR_LEVEL_3p1_3p2)
/* OB_IWDG_SW/OB_IWDG_HW */
#define USER_IWDG_SW_CONFIG (OB_IWDG_SW)
/* OB_WWDG_SW/OB_WWDG_HW */
#define USER_WWDG_SW_CONFIG (OB_WWDG_SW)
/* OB_RESET_MODE_RESET/OB_RESET_MODE_GPIO */
#define USER_RESET_MODE_CONFIG (OB_RESET_MODE_RESET)
/* OB_BOOT1_SRAM/OB_BOOT1_SYSTEM */
#define USER_nBOOT1_CONFIG (OB_BOOT1_SYSTEM)
/* reference user manual */
/* 0：sector[y]被保护/ 1：sector[y]无保护; Production value: 0x0000 FFFF */
#define USER_WRPSector_CONFIG (0xFFFF)
/* Production value: 0xFF00 00FF */
#define USER_SDKStartAddr_CONFIG (0x1FUL)
#define USER_SDKEndAddr_CONFIG (0x00UL)
/* OB_RDP_LEVEL_0/OB_RDP_LEVEL_1 */
#define USER_RDPLevel_CONFIG (OB_RDP_LEVEL_0)

FLASH_OBProgramInitTypeDef OBInitCfg;
UART_HandleTypeDef UartHandle_CH340E;


/**
 * print 串口重定义
 */
int fputc(int ch, FILE *f)
{
  HAL_UART_Transmit(&UartHandle_CH340E, (uint8_t *)&ch, 1, 0xFFFF);
  return ch;
}
/**
 * 用户GPIO配置
 */
void user_gpio_config(void)
{
  GPIO_InitTypeDef GPIO_InitStruct;
  __HAL_RCC_GPIOB_CLK_ENABLE(); // GPIOB时钟使能
  // 初始化GPIOB5
  GPIO_InitStruct.Pin = GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;        // 推挽输出
  GPIO_InitStruct.Pull = GPIO_PULLUP;                // 使能上拉
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH; // GPIO速度
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);            // GPIO初始化
}
/**
 * 用户串口配置
 */
void user_uart_config(void)
{
  UartHandle_CH340E.Instance = USART1;
  UartHandle_CH340E.Init.BaudRate = 115200;
  UartHandle_CH340E.Init.WordLength = UART_WORDLENGTH_8B;
  UartHandle_CH340E.Init.StopBits = UART_STOPBITS_1;
  UartHandle_CH340E.Init.Parity = UART_PARITY_NONE;
  UartHandle_CH340E.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  UartHandle_CH340E.Init.Mode = UART_MODE_TX_RX;

#ifdef DEF_OVERSAMPLING_8
  UartHandle_CH340E.Init.OverSampling = UART_OVERSAMPLING_8;
#endif

  if (HAL_UART_Init(&UartHandle_CH340E) != HAL_OK)
  {
    Error_Handler();
  }
}
void user_read_option_byte()
{
  HAL_FLASH_OBGetConfig(&OBInitCfg);
  printf("WRPSector 0x%04x\r\n", (uint16_t)(FLASH->WRPR));
  printf("SDKStartAddr 0x%02x\r\n", (FLASH->SDKR)&0x1F);
  printf("SDKEndAddr 0x%02x\r\n", ((FLASH->SDKR)&0x1F00)>>8);
  printf("RDPLevel 0x%02x\r\n", (uint32_t)(OBInitCfg.RDPLevel));
  printf("BOR_EN 0x%02x\r\n", (uint32_t)((OBInitCfg.USERConfig >> FLASH_OPTR_BOR_EN_Pos) & (0x01UL)));
  printf("BOR_LEV 0x%02x\r\n", (uint32_t)((OBInitCfg.USERConfig >> FLASH_OPTR_BOR_LEV_Pos) & (0x07UL)));
  printf("IWDG_SW 0x%02x\r\n", (uint32_t)((OBInitCfg.USERConfig >> FLASH_OPTR_IWDG_SW_Pos) & (0x01UL)));
  printf("WWDG_SW 0x%02x\r\n", (uint32_t)((OBInitCfg.USERConfig >> FLASH_OPTR_WWDG_SW_Pos) & (0x01UL)));
  printf("NRST_MODE 0x%02x\r\n", (uint32_t)((OBInitCfg.USERConfig >> FLASH_OPTR_NRST_MODE_Pos) & (0x01UL)));
  printf("nBOOT1 0x%02x\r\n", (uint32_t)((OBInitCfg.USERConfig >> FLASH_OPTR_nBOOT1_Pos) & (0x01UL)));
}
void user_program_option_byte()
{
  HAL_FLASH_Unlock();    // 解锁FLASH
  HAL_FLASH_OB_Unlock(); // 解锁FLASH OPTION
  OBInitCfg.OptionType = OPTIONBYTE_ALL;
  OBInitCfg.WRPSector = ~USER_WRPSector_CONFIG;
  OBInitCfg.SDKStartAddr = USER_SDKStartAddr_CONFIG;
  OBInitCfg.SDKEndAddr = USER_SDKEndAddr_CONFIG;
  OBInitCfg.RDPLevel = USER_RDPLevel_CONFIG;
  OBInitCfg.USERConfig = USER_BOR_ENABLE_CONFIG | USER_BOR_LEVEL_CONFIG | USER_IWDG_SW_CONFIG | USER_WWDG_SW_CONFIG | USER_RESET_MODE_CONFIG | USER_nBOOT1_CONFIG;
  /* 启动option byte编程 */
  HAL_FLASH_OBProgram(&OBInitCfg);
  HAL_FLASH_Lock();
  HAL_FLASH_OB_Lock();
  printf("ready rest\r\n");
  /* 产生一个复位，option byte装载 */
  HAL_FLASH_OB_Launch();

}
int main(void)
{
  /*初始化systick*/
  HAL_Init();
	HAL_Delay(500);
	user_gpio_config();
  user_uart_config();
  printf("User Option Example Begin\r\n");
  printf("current option byte info\r\n");
  user_read_option_byte();
  do
  {
    if ((OBInitCfg.USERConfig & FLASH_OPTR_BOR_EN_Msk) != USER_BOR_ENABLE_CONFIG)
    {
      printf("USER_BOR_ENABLE_CONFIG need updata, 0x%x, 0x%x\r\n", (uint32_t)(OBInitCfg.USERConfig & FLASH_OPTR_BOR_EN_Msk),(uint32_t)USER_BOR_ENABLE_CONFIG);
      user_program_option_byte();
      break;
    }
    else if ((OBInitCfg.USERConfig & FLASH_OPTR_BOR_LEV_Msk) != USER_BOR_LEVEL_CONFIG)
    {
      printf("USER_BOR_LEVEL_CONFIG need updata, 0x%x, 0x%x\r\n", (uint32_t)(OBInitCfg.USERConfig & FLASH_OPTR_BOR_LEV_Msk) , (uint32_t)USER_BOR_LEVEL_CONFIG);
      user_program_option_byte();
      break;
    }
    else if ((OBInitCfg.USERConfig & FLASH_OPTR_IWDG_SW_Msk) != USER_IWDG_SW_CONFIG)
    {
      printf("USER_IWDG_SW_CONFIG need updata, 0x%x, 0x%x\r\n", (uint32_t)(OBInitCfg.USERConfig & FLASH_OPTR_IWDG_SW_Msk) , (uint32_t)USER_IWDG_SW_CONFIG);
      user_program_option_byte();
      break;
    }
    else if ((OBInitCfg.USERConfig & FLASH_OPTR_WWDG_SW_Msk) != USER_WWDG_SW_CONFIG)
    {
      printf("USER_WWDG_SW_CONFIG need updata, 0x%x, 0x%x\r\n", (uint32_t)(OBInitCfg.USERConfig & FLASH_OPTR_WWDG_SW_Msk) , (uint32_t)USER_WWDG_SW_CONFIG);
      user_program_option_byte();
      break;
    }
    else if ((OBInitCfg.USERConfig & FLASH_OPTR_NRST_MODE_Msk) != USER_RESET_MODE_CONFIG)
    {
      printf("USER_RESET_MODE_CONFIG need updata, 0x%x, 0x%x\r\n", (uint32_t)(OBInitCfg.USERConfig & FLASH_OPTR_NRST_MODE_Msk) , (uint32_t)USER_RESET_MODE_CONFIG);
      user_program_option_byte();
      break;
    }
    else if ((OBInitCfg.USERConfig & FLASH_OPTR_nBOOT1_Msk) != USER_nBOOT1_CONFIG)
    {
      printf("USER_nBOOT1_CONFIG need updata, 0x%x, 0x%x\r\n", (uint32_t)(OBInitCfg.USERConfig & FLASH_OPTR_nBOOT1_Msk) , (uint32_t)USER_nBOOT1_CONFIG);
      user_program_option_byte();
      break;
    }
    else if ((OBInitCfg.RDPLevel) != USER_RDPLevel_CONFIG)
    {
      printf("USER_RDPLevel_CONFIG need updata, 0x%x, 0x%x\r\n", (uint32_t)((OBInitCfg.RDPLevel) & (0xFFUL)) , (uint32_t)USER_RDPLevel_CONFIG);
      user_program_option_byte();
      break;
    }
    else if ((uint16_t)(FLASH->WRPR) != USER_WRPSector_CONFIG)
    {
      printf("USER_WRPSector_CONFIG need updata, 0x%x, 0x%x\r\n", (uint16_t)(FLASH->WRPR) , (uint16_t)USER_WRPSector_CONFIG);
      user_program_option_byte();
      break;
    }
    else if (((OBInitCfg.SDKStartAddr) & (0xFFUL)) != (USER_SDKStartAddr_CONFIG & 0x1FUL))
    {
      printf("USER_SDKStartAddr_CONFIG need updata, 0x%x, 0x%x\r\n", (uint32_t)((OBInitCfg.SDKStartAddr) & (0xFFUL)) , (uint32_t)(USER_SDKStartAddr_CONFIG & 0x1FUL));
      user_program_option_byte();
      break;
    }
    else if (((OBInitCfg.SDKEndAddr) & (0xFFUL)) != (USER_SDKEndAddr_CONFIG & 0x1FUL))
    {
      printf("USER_SDKEndAddr_CONFIG need updata, 0x%x, 0x%x\r\n", (uint32_t)((OBInitCfg.SDKEndAddr) & (0xFFUL)) , (uint32_t)(USER_SDKEndAddr_CONFIG & 0x1FUL));
      user_program_option_byte();
      break;
    }
    else
    {
      printf("No update is required\r\n");
    }
  } while (0);
  
  printf("User Option Example End\r\n");
  while (1)
  {
		HAL_Delay(500);
		HAL_GPIO_TogglePin(GPIOB,GPIO_PIN_5);
  }
}



void Error_Handler(void)
{
  while (1)
  {
  }
}

#ifdef USE_FULL_ASSERT
/**
 * @brief  Reports the name of the source file and the source line number
 *         where the assert_param error has occurred.
 * @param  file: pointer to the source file name
 * @param  line: assert_param error line source number
 * @retval None
 */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
}
#endif /* USE_FULL_ASSERT */

/* Private function -------------------------------------------------------*/
