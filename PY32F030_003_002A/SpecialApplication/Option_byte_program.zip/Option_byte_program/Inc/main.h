/**
  ******************************************************************************
  * @file    main.h
  * @author  MCU Application Team
  * @Version V1.0.0
  * @Date    
  * @brief   Header for main.c file.
  *          This file contains the common defines of the application.
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "py32f0xx_hal.h"

/* Private includes ----------------------------------------------------------*/

#include <stdbool.h>

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* UART_CH340E ��ض��� */
#define UART_CH340E                           USART1
#define UART_CH340E_CLK_ENABLE()              __HAL_RCC_USART1_CLK_ENABLE()
#define UART_CH340E_RX_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOA_CLK_ENABLE()
#define UART_CH340E_TX_GPIO_CLK_ENABLE()      __HAL_RCC_GPIOA_CLK_ENABLE()

#define UART_CH340E_FORCE_RESET()             __HAL_RCC_USART1_FORCE_RESET()
#define UART_CH340E_RELEASE_RESET()           __HAL_RCC_USART1_RELEASE_RESET()

/* Definition for UART_CH340E Pins */
#define UART_CH340E_TX_PIN                    GPIO_PIN_9
#define UART_CH340E_TX_GPIO_PORT              GPIOA
#define UART_CH340E_TX_AF                     GPIO_AF1_USART1
#define UART_CH340E_RX_PIN                    GPIO_PIN_10
#define UART_CH340E_RX_GPIO_PORT              GPIOA
#define UART_CH340E_RX_AF                     GPIO_AF1_USART1

/* Definition for UART_CH340E's NVIC */
#define UART_CH340E_IRQn                      USART1_IRQn
#define UART_CH340E_IRQHandler     


#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */

