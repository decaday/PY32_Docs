/**
  ******************************************************************************
  * @file    main.h
  * @author  Puya Application Team
  * @brief   Header for main.c module
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 Puya Semiconductor.
  * All rights reserved.</center></h2>
  *
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

/* Includes ------------------------------------------------------------------*/
#include "py32f0xx.h"

/* Exported types ------------------------------------------------------------*/
#define RET_ERROR_NACK  ERROR
#define RET_SUCCESS_ACK SUCCESS

/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
#define M8(adr)  (*((__IO uint8_t *) (adr)))
#define M16(adr) (*((__IO uint16_t *) (adr)))
#define M32(adr) (*((__IO uint32_t *) (adr)))

//#define SET_BIT(REG, BIT)     ((REG) |= (BIT))
//#define CLEAR_BIT(REG, BIT)   ((REG) &= ~(BIT))
//#define READ_BIT(REG, BIT)    ((REG) & (BIT))
//#define CLEAR_REG(REG)        ((REG) = (0x0))
//#define WRITE_REG(REG, VAL)   ((REG) = (VAL))
//#define READ_REG(REG)         ((REG))
//#define MODIFY_REG(REG, CLEARMASK, SETMASK)  WRITE_REG((REG), (((READ_REG(REG)) & (~(CLEARMASK))) | (SETMASK)))
//#define CLEAR_WPBIT(REG, CLEARMASK, WPKEY) WRITE_REG((REG), ((READ_REG(REG)) & (~(CLEARMASK))) | WPKEY)
//#define POSITION_VAL(VAL)     (__CLZ(__RBIT(VAL))) 
//#define UNUSED(X) (void)X      /* To avoid gcc/g++ warnings */

#define COUNTOF(__BUFFER__)   (sizeof(__BUFFER__) / sizeof(*(__BUFFER__)))
	
#ifdef _DEBUG
#define TRACE printf
#else
#define TRACE(...); 
#endif

/* Exported functions ------------------------------------------------------- */

#endif /* __MAIN_H */

/************************ (C) COPYRIGHT Puya Semiconductor *****END OF FILE****/
