/**
  ******************************************************************************
  * @file    py32f030_hal_led.h
  * @author  MCU Application Team
  * @brief   Header file of LED HAL module.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) Puya Semiconductor Co.
  * All rights reserved.</center></h2>
  *
  * This software is owned and published by:
  * Puya Semiconductor Co., Ltd.
  * Redistribution and use in source and binary forms, with or without
  * modification, are permitted provided that the following conditions are met:
  *
  *  1. Redistributions of source code must retain the above copyright notice,
  *     this list of conditions and the following disclaimer.
  *  2. Redistributions in binary form must reproduce the above copyright notice,
  *     this list of conditions and the following disclaimer in the documentation
  *     and/or other materials provided with the distribution.
  *  3. Neither the name of the copyright holder nor the names of its contributors
  *     may be used to endorse or promote products derived from this software
  *     without specific prior written permission.
  *
  *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  *  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  *  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
  *  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
  *  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  *  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  *  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
  *  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  *  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  *  POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

#ifndef __PY32F030_HAL_LED_H
#define __PY32F030_HAL_LED_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "py32f030_hal_def.h"



/**
  * @brief LED Init Structure definition
  */
typedef struct
{
    uint32_t EHS;                  /*!< This member configures the LED*/

    uint32_t PR;                /*!< Specifies prescaler.*/

    uint32_t Com_sel;                  /*!< Specifies the number of com.  */

    uint32_t TR_T1;                    /*!< Specifies switch timing. . */

    uint32_t TR_T2;                    /*!< Specifies switch timing. . */


} LED_InitTypeDef;

#if (USE_HAL_LED_REGISTER_CALLBACKS == 1)
typedef struct __LED_HandleTypeDef
#else
typedef struct
#endif
{
    LED_TypeDef       *Instance;
    
    LED_InitTypeDef   Init;
    
#if (USE_HAL_LED_REGISTER_CALLBACKS == 1)
    void (* MspInitCallback)(struct __LED_HandleTypeDef *hled);
    
    void (* LightComplateCallback)(struct __LED_HandleTypeDef *hled);
#endif
} LED_HandleTypeDef;

#define __HAL_LED_ENABLE(__HANDLE__)                  SET_BIT((__HANDLE__)->Instance->CR, LED_CR_LEDON)

/** @brief  Disable the specified LED peripheral.
  * @param  __HANDLE__ specifies the LED Handle.
  * @retval None
  */
#define __HAL_LED_DISABLE(__HANDLE__)                 CLEAR_BIT((__HANDLE__)->Instance->CR, LED_CR_LEDON)

#define __HAL_LED_CLEAR_FLAG(__HANDLE__, __FLAG__)    ((__HANDLE__)->Instance->IR = (__FLAG__))

#define __HAL_LED_ENABLE_IT(__HANDLE__, __INTERRUPT__)       SET_BIT((__HANDLE__)->Instance->CR, (__INTERRUPT__))

#define LED_Disp_0        0x3f
#define LED_Disp_1        0x06
#define LED_Disp_2        0x5b
#define LED_Disp_3        0x4f
#define LED_Disp_4        0x66
#define LED_Disp_5        0x6d
#define LED_Disp_6        0x7d
#define LED_Disp_7        0x07
#define LED_Disp_8        0x7f
#define LED_Disp_9        0x6f
#define LED_Disp_0dot     0xbf
#define LED_Disp_1dot     0x86
#define LED_Disp_2dot     0xdb
#define LED_Disp_3dot     0xcf
#define LED_Disp_4dot     0xe6
#define LED_Disp_5dot     0xed
#define LED_Disp_6dot     0xfd
#define LED_Disp_7dot     0x87
#define LED_Disp_8dot     0xff
#define LED_Disp_9dot     0xef
#define LED_Disp_A        0x77
#define LED_Disp_B        0x7C
#define LED_Disp_C        0x39
#define LED_Disp_D        0x5E
#define LED_Disp_E        0x79
#define LED_Disp_F        0x71
#define LED_Disp_H        0x76
#define LED_Disp_P        0x73
#define LED_Disp_U        0x3e

#define LED_COM0          0x00
#define LED_COM1          0x01
#define LED_COM2          0x02
#define LED_COM3          0x03

#define LED_COM_SEL_COM0            0
#define LED_COM_SEL_COM0_1          LED_CR_LED_COM_SEL_0
#define LED_COM_SEL_COM0_1_2        LED_CR_LED_COM_SEL_1
#define LED_COM_SEL_COM0_1_2_3      (LED_CR_LED_COM_SEL_0 | LED_CR_LED_COM_SEL_1)

#define LED_COM_DRIVER_LOW          0
#define LED_COM_DRIVER_HIGH         LED_CR_EHS

HAL_StatusTypeDef HAL_LED_Init(LED_HandleTypeDef *hled);
void HAL_LED_MspInit(LED_HandleTypeDef *hled);
HAL_StatusTypeDef Led_FullDisp(void);
HAL_StatusTypeDef Led_ClearDisp(void);
HAL_StatusTypeDef Led_SetComNumber(LED_HandleTypeDef *hled, uint8_t COM_x, uint8_t Data);
void HAL_LED_LightComplateCallback(LED_HandleTypeDef *hled);
void HAL_LED_IRQHandler(LED_HandleTypeDef *hled);

#endif
