/**
  ******************************************************************************
  * @file    py32f030_hal_led.c
  * @author  LED Application Team
  * @brief   LED HAL module driver.

  @verbatim
  ===================================================
	**/
    
/* Includes ------------------------------------------------------------------*/
#include "py32f030_hal.h"

#ifdef HAL_LED_MODULE_ENABLED 
static void LED_SetConfig(LED_HandleTypeDef *hled);

HAL_StatusTypeDef HAL_LED_Init(LED_HandleTypeDef *hled)
{
    /* Check the LED handle allocation */
    if (hled == NULL)
    {
        return HAL_ERROR;
    }
    assert_param(IS_LED_ALL_INSTANCE(hled->Instance));
        
#if (USE_HAL_LED_REGISTER_CALLBACKS == 1)
    /* Reset Callback pointers */
    if (hled->EwiCallback == NULL)
    {
        hled->EwiCallback = HAL_LED_LightComplateCallback;
    }

    if (hled->MspInitCallback == NULL)
    {
        hled->MspInitCallback = HAL_LED_MspInit;
    }

  /* Init the low level hardware */
  hled->MspInitCallback(hwwdg);
#else
    HAL_LED_MspInit(hled);
#endif

    LED_SetConfig(hled);
    __HAL_LED_ENABLE(hled);

    return HAL_OK;
}
HAL_StatusTypeDef Led_FullDisp(void)
{
    LED->DR0=0xff;
    LED->DR1=0xff;
    LED->DR2=0xff;
    LED->DR3=0xff;
    
    return HAL_OK;
}

HAL_StatusTypeDef Led_ClearDisp(void)
{
    LED->DR0=0x00;
    LED->DR1=0x00;
    LED->DR2=0x00;
    LED->DR3=0x00;
    
    return HAL_OK;
}

HAL_StatusTypeDef Led_SetComNumber(LED_HandleTypeDef *hled, uint8_t dataCh, uint8_t Data)
{
    uint32_t *pTmp = ((uint32_t *)&hled->Instance->DR0) + dataCh;
    
    WRITE_REG(*pTmp, Data);
//    if(COM_x == LED_COM0)      //COM0
//    {
//        WRITE_REG(hled->Instance->DR0, Data);
//    }
//    else if(COM_x == LED_COM1) //COM1
//    {
//        WRITE_REG(hled->Instance->DR1, Data);
//    }
//    else if(COM_x ==LED_COM2)  //COM2
//    {
//        WRITE_REG(hled->Instance->DR2, Data);
//    }
//    else if(COM_x == LED_COM3) //COM3
//    {
//        WRITE_REG(hled->Instance->DR3, Data);
//    }
    
    return HAL_OK;
}
static void LED_SetConfig(LED_HandleTypeDef *hled)
{
    uint32_t tmpreg;

    tmpreg=hled->Init.EHS|hled->Init.Com_sel;
    MODIFY_REG(hled->Instance->CR,
               (uint32_t)(LED_CR_LED_COM_SEL | LED_CR_EHS),
               tmpreg);
    WRITE_REG(hled->Instance->PR, hled->Init.PR);
    WRITE_REG(hled->Instance->TR, (hled->Init.TR_T1 | (hled->Init.TR_T2<<8)));
}

/**
  * @brief Handle UART interrupt request.
  * @param huart UART handle.
  * @retval None
  */
void HAL_LED_IRQHandler(LED_HandleTypeDef *hled)
{
    /* LED interrupt occurred -------------------------------------*/
    if (((hled->Instance->IR & LED_IR_FLAG) != 0U) && ((hled->Instance->CR & LED_CR_IE) != 0U))
    {
      __HAL_LED_CLEAR_FLAG(hled, LED_IR_FLAG);

      HAL_LED_LightComplateCallback(hled);
    }
}

__weak void HAL_LED_MspInit(LED_HandleTypeDef *hled)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(hled);

    /* NOTE : This function should not be modified, when the callback is needed,
              the HAL_I2C_MspInit could be implemented in the user file
     */
}

__weak void HAL_LED_LightComplateCallback(LED_HandleTypeDef *hled)
{
    /* Prevent unused argument(s) compilation warning */
    UNUSED(hled);

    /* NOTE : This function should not be modified, when the callback is needed,
              the HAL_LED_LightComplateCallback could be implemented in the user file
     */
}

#endif /* HAL_LED_MODULE_ENABLED */

