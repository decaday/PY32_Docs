/**
  ******************************************************************************
  * @file    main.c
	* @author  MCU SYSTEM Team
	* @Version V1.0.0
  * @Date    2020-10-19
  * @brief   main function
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#define APPLICATION_ADDRESS     (uint32_t)0x08001000
__IO uint32_t VectorTable[48] __attribute__((at(SRAM_BASE)));

/* Private variables ---------------------------------------------------------*/
LPTIM_HandleTypeDef 			LPTIMCONF={0};
/* Clocks structure declaration */
/* Private function prototypes -----------------------------------------------*/
/* Private user code ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
void Error_Handler(void);
static void APP_RCC_OscConfig(void);
static void APP_LPTIM_INIT(void);
void LED_RUN(uint32_t Delay);
/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
	uint8_t i,lptimer_cnt;
	for(i = 0; i < 48; i++)
 {
  VectorTable[i] = *(__IO uint32_t*)(APPLICATION_ADDRESS + (i<<2));
 }
	SCB->VTOR = SRAM_BASE; 
	//外设、systick初始化
	HAL_Init();
	//时钟设置
	APP_RCC_OscConfig();
	//LPTIM初始化
 		APP_LPTIM_INIT();

	BSP_LED_On(LED_GREEN);
	//等待按键按下
	while(BSP_PB_GetState(BUTTON_USER) != 0)
	{
	}
	HAL_NVIC_SetPriority( LPTIM_IRQn, 0x01,  0);
	HAL_NVIC_EnableIRQ( LPTIM_IRQn);

	BSP_LED_Off(LED_GREEN);
//	__HAL_LPTIM_START_SINGLE(&LPTIMCONF);

	while(1)
	{
		//复位LPTMIE 模块
		lptimer_cnt=(LPTIM->CNT);
		if((LPTIM->CNT)==0)
		{
			SET_BIT(RCC->APBRSTR1,RCC_APBRSTR1_LPTIMRST);			
			CLEAR_BIT(RCC->APBRSTR1,RCC_APBRSTR1_LPTIMRST);
			//初始化 LPTIME
	//		APP_LPTIM_INIT();
	//		if(HAL_LPTIM_Counter_Start_IT(&LPTIMCONF, 0xC00) != HAL_OK)	//使能LPTIME中断
	//		{
	//			Error_Handler();
	//		}
	//		
	//		__HAL_LPTIM_START_SINGLE(&LPTIMCONF);												//使能LPTMIE

			WRITE_REG(LPTIM->CFGR,3<<9);
			WRITE_REG(LPTIM->IER,2);			//使能LPTIM中断
			WRITE_REG(LPTIM->CR,1);				//使能LPTIM
			WRITE_REG(LPTIM->ARR,0xC00);
			
			SET_BIT(LPTIM->CR,LPTIM_CR_SNGSTRT);		//使能
			
			//进STOP模式
			HAL_PWR_EnterSTOPMode(PWR_LOWPOWERREGULATOR_ON, PWR_STOPENTRY_WFI);	
		}
	}
}


void Error_Handler(void)
{
    while (1)
    {
    }
}

static void APP_RCC_OscConfig(void)
{
	RCC_OscInitTypeDef OSCINIT;
	RCC_PeriphCLKInitTypeDef LPTIM_RCC;

	__HAL_RCC_LPTIM_CLK_ENABLE();
	
	OSCINIT.OscillatorType = RCC_OSCILLATORTYPE_LSI;
	OSCINIT.LSIState = RCC_LSI_ON;
	
	LPTIM_RCC.PeriphClockSelection = RCC_PERIPHCLK_LPTIM;
	LPTIM_RCC.LptimClockSelection = RCC_LPTIMCLKSOURCE_LSI;		//选用LSI作为LPTIM的时钟源
	
	if(HAL_RCCEx_PeriphCLKConfig(&LPTIM_RCC) != HAL_OK)
	{
		Error_Handler();
	}
	
	if(HAL_RCC_OscConfig(&OSCINIT) != HAL_OK)
	{
		Error_Handler();
	}
}

static void APP_LPTIM_INIT(void)
{
	LPTIMCONF.Instance = LPTIM;
	LPTIMCONF.Init.Clock.Prescaler = LPTIM_PRESCALER_DIV8;		//LSI 32分频
	LPTIMCONF.Init.UpdateMode = LPTIM_UPDATE_IMMEDIATE;
	 
	if(HAL_LPTIM_Init(&LPTIMCONF) != HAL_OK)
	{
		Error_Handler();
	}
}


void HAL_LPTIM_AutoReloadMatchCallback(LPTIM_HandleTypeDef *hlptim)
{
	BSP_LED_Toggle(LED_GREEN);
}

void LED_RUN(uint32_t Delay)
{
	BSP_LED_Toggle(LED_GREEN);
	HAL_Delay(Delay);
	BSP_LED_Toggle(LED_GREEN);
	HAL_Delay(Delay);
}
#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
    /* USER CODE BEGIN 6 */
    /* User can add his own implementation to report the file name and line number,
       tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
    /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */


/* Private function -------------------------------------------------------*/



