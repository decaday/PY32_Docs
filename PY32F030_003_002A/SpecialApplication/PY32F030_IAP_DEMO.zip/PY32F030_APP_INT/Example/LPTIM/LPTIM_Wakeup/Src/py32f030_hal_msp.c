/**
  ******************************************************************************
  * @file    p32f030_hal_msp.c
	* @author  MCU SYSTEM Team
	* @Version V1.0.0
  * @Date    2020-10-19
  * @brief   This file provides code for the MSP Initialization
  *          and de-Initialization codes.
  ******************************************************************************
  */


/* Includes ------------------------------------------------------------------*/
#include "main.h"
/**
* @brief LPTIM MSP Initialization
* This function configures the hardware resources used in this example
* @param hlptim: LPTIM handle pointer
* @retval None
*/
void HAL_MspInit(void)
{
    /* USER CODE BEGIN MspInit 0 */
	BSP_LED_Init(LED3);
	BSP_PB_Init(BUTTON_USER,BUTTON_MODE_GPIO);
	
    /* USER CODE END MspInit 0 */
}
