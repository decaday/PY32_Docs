#include <py32f0xx.h>

#define rcc_gpio_b 0x40021034UL
/**
 * @brief ������ʱ
 */
void delay(uint32_t delay_time)
{
    while (delay_time--)
        ;
}
/**
 * @brief ������
 */
int main()
{
    *(uint32_t *)rcc_gpio_b |= 0x02;
    *(uint32_t *)0x50000400UL &= ~(0x03 << 10);
    *(uint32_t *)0x50000400UL |= (0x01 << 10);
    *(uint32_t *)0x50000418UL |= (0x1UL << 5);
    while (1)
    {
        *(uint32_t *)0x50000414UL = *(uint32_t *)0x50000414UL ^ (0x1UL << 5);
        delay(0x1FFFF);
    }
}
